let hash        = require('object-hash');
let validator   = require("./validator");
let mongoose    = require("mongoose");
let blockChainModel = mongoose.model("BlockChain");
let chalk       = require("chalk");

const TARGET_HASH = hash(1560);

class BlockChain {
    constructor() { 
        //create
        this.chain = [];
        // transactions
        this.curr_transactions = [];
    }
    
    async getLastBlock() {
        try {
            const block = await blockChainModel.findOne({}, null, { sort: { _id: -1 }, limit: 1 });
            return block;  // Devuelve el bloque encontrado
        } catch (err) {
            console.error("Error fetching block:", err); 
            throw new Error("Error fetching block");
        }
    }   

    async addNewBlock(prevHash){
        let block = {
            index: this.chain.length + 1,
            timestamp: Date.now(),
            transactions: this.curr_transactions,
            prevHash: prevHash,
        }

        if (validator.proofOfWork() == TARGET_HASH){
            block.hash = hash(block); //Calcula el hash del bloque

            try {
                const lastBlock = await this.getLastBlock();// Espera a obtener el último bloque
                console.log("Último bloque:", lastBlock);
        
                if (lastBlock) {
                    // Si existe un último bloque, asigna el `prevHash` al nuevo bloque
                    block.prevHash = lastBlock.hash;
                }
            
                // crea un nuevo bloque en el modelo mongoose
                let newBlock = new blockChainModel(block);

                // Función asincrónica para guardar el bloque
                const saveBlock = async (newBlock) => { 
                    newBlock.save()
                        .then(() => {
                            console.log(chalk.green("Block Saved on the DB"));
                        })
                        .catch((err) => {
                            console.log(chalk.red("Cannot save Block to DB", err.message));
                        });
                };
                saveBlock(newBlock); // Guarda el bloque 
                console.log("datos internos", newBlock);

                this.hash = hash(block); //poner hash
                this.chain.push(block);  // agrega el bloque a la cadena
                this.curr_transactions = []; 
                return block;

            } catch (err) {
                console.error("Error al agregar el bloque:", err);
            }
        }
    }
    
    addNewTransaction(sender, recipient, amount){
        this.curr_transactions.push({sender, recipient, amount})
    }

    lastBlock(){
        return this.chain.slice(-1)[0];
    }

    isEmpty(){
        return this.chain.lenght == 0;
    }
}

module.exports = BlockChain;
