let mongoose = require("mongoose");
let BlockChainModel = require("./model");

// Función para conectar con la base de datos usando async/await
const connectToDatabase = async () => {
    try {
        await mongoose.connect("mongodb://localhost:27017/blockChain", {});
        console.log("Database is Connected");
        connectionCallback(); // Llama al callback después de conectarte exitosamente
    } catch (err) {
        console.error("Cannot connect to DB:", err.message);
    }
};

let connectionCallback = () => {};

module.exports.onConnect = (callback) =>{
    connectionCallback = callback;
}

connectToDatabase();





