let hash = require('object-hash');

const TARGET_HASH = 1560;

module.exports.validProof = (proof) => {
    let  guessHash = hash(proof);
    console.log("Hashing: ", guessHash);
    return guessHash == hash(TARGET_HASH);
}; 

module.exports.proofOfWork = () => {
    let proof = 0;
    const maxAttempts = 1000000;  // Límite de intentos
    let attempts = 0;


    while(true) {
        if(!module.exports.validProof(proof)){
            proof++;
        }else{
            break;
        }

        // Si se alcanza el límite de intentos, termina el bucle
        if (attempts > maxAttempts) {
            console.log("No se encontró una solución después de " + maxAttempts + " intentos.");
            return null;  // O puedes lanzar un error si prefieres
        }
    }
    return hash(proof);
}
