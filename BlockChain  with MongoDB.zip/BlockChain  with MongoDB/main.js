let database = require("./src/database");
database.onConnect(()=> {

    let BlockChain  = require('./src/blockchain');
    let blockchain  = new BlockChain();
    let hash        = require('object-hash');

    //let PROOF       = 1560;

    blockchain.addNewTransaction("Felipe","Bernal",500);
    let prevHash = blockchain.lastBlock() ? blockchain.lastBlock().hash : null;
    blockchain.addNewBlock(prevHash);
   
    /*blockchain.addNewTransaction("Andres","Abril",200);
    blockchain.addNewBlock(null);*/


    console.log("Chain : ", blockchain.chain);
});